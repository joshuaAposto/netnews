import { drizzle } from "drizzle-orm/neon-http";
import { neon } from '@neondatabase/serverless';
import * as schema from "@shared/schema";

if (!process.env.DATABASE_URL) {
  throw new Error(
    "DATABASE_URL must be set. Did you forget to provision a database?",
  );
}

// Neon serverless configuration
export const sqlClient = neon(process.env.DATABASE_URL);
export const db = drizzle({ client: sqlClient, schema });

// Simple way to ensure tables exist in this environment
async function initDb() {
  try {
    // Check if users table exists
    await sqlClient`SELECT 1 FROM users LIMIT 1`.catch((e) => {
      // Check for relation does not exist error (Postgres code 42P01)
      if (e.message && (e.message.includes('relation "users" does not exist') || e.message.includes('42P01'))) {
        throw e;
      }
      return [];
    });
  } catch (e: any) {
    if (e.message && (e.message.includes('relation "users" does not exist') || e.message.includes('42P01'))) {
      console.log("Tables don't exist, creating them...");
      // Use raw sqlClient for DDL
      await sqlClient`
        CREATE TABLE IF NOT EXISTS users (
          id SERIAL PRIMARY KEY,
          name VARCHAR(255) NOT NULL,
          username VARCHAR(255) UNIQUE NOT NULL,
          email VARCHAR(255) UNIQUE NOT NULL,
          password TEXT NOT NULL,
          role VARCHAR(50) NOT NULL DEFAULT 'user',
          profile_image_url TEXT,
          created_at TIMESTAMP DEFAULT NOW(),
          updated_at TIMESTAMP DEFAULT NOW()
        );
      `;
      await sqlClient`
        CREATE TABLE IF NOT EXISTS articles (
          id SERIAL PRIMARY KEY,
          title TEXT NOT NULL,
          content TEXT NOT NULL,
          category TEXT NOT NULL,
          image_url TEXT,
          video_url TEXT,
          is_featured BOOLEAN DEFAULT FALSE,
          view_count INTEGER DEFAULT 0,
          author_id VARCHAR(255) NOT NULL,
          created_at TIMESTAMP DEFAULT NOW()
        );
      `;
      await sqlClient`
        CREATE TABLE IF NOT EXISTS comments (
          id SERIAL PRIMARY KEY,
          article_id INTEGER NOT NULL REFERENCES articles(id),
          user_id VARCHAR(255) NOT NULL,
          content TEXT NOT NULL,
          created_at TIMESTAMP DEFAULT NOW()
        );
      `;
      await sqlClient`
        CREATE TABLE IF NOT EXISTS reactions (
          id SERIAL PRIMARY KEY,
          article_id INTEGER NOT NULL REFERENCES articles(id),
          user_id VARCHAR(255) NOT NULL,
          type TEXT NOT NULL
        );
      `;
      console.log("Tables created successfully.");
    } else {
      console.error("Database initialization error:", e);
    }
  }
}

initDb().catch(console.error);
