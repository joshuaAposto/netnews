import { db, sqlClient } from "./db";
import { eq, desc, and, ilike, sql } from "drizzle-orm";
import { 
  articles, 
  comments, 
  reactions,
  type InsertArticle,
  type InsertComment,
  type InsertReaction,
  type Article,
  type Comment,
  type Reaction,
  users,
  type User,
  type InsertUser
} from "@shared/schema";

export interface IStorage {
  // Articles
  getArticles(params?: { category?: string, isFeatured?: string, trending?: string, search?: string }): Promise<Article[]>;
  getArticle(id: number): Promise<Article | undefined>;
  createArticle(article: InsertArticle): Promise<Article>;
  updateArticle(id: number, article: Partial<InsertArticle>): Promise<Article>;
  deleteArticle(id: number): Promise<void>;
  incrementArticleView(id: number): Promise<void>;

  // Comments
  getComments(articleId: number): Promise<any[]>;
  createComment(comment: InsertComment & { userId: string }): Promise<Comment>;

  // Reactions
  getReactions(articleId: number): Promise<Reaction[]>;
  toggleReaction(reaction: InsertReaction & { userId: string }): Promise<Reaction | { removed: true }>;

  // Users
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updateData: any): Promise<User>;
}

export class DatabaseStorage implements IStorage {
  async getUserByEmail(email: string) {
    const results = await sqlClient`SELECT * FROM users WHERE email = ${email}`;
    const u = results[0];
    if (!u) return undefined;
    return {
      id: u.id,
      name: u.name,
      username: u.username,
      email: u.email,
      password: u.password,
      role: u.role,
      profileImageUrl: u.profile_image_url,
      createdAt: u.created_at,
      updatedAt: u.updated_at
    };
  }

  async getUserByUsername(username: string) {
    const results = await sqlClient`SELECT * FROM users WHERE username = ${username}`;
    const u = results[0];
    if (!u) return undefined;
    return {
      id: u.id,
      name: u.name,
      username: u.username,
      email: u.email,
      password: u.password,
      role: u.role,
      profileImageUrl: u.profile_image_url,
      createdAt: u.created_at,
      updatedAt: u.updated_at
    };
  }

  async createUser(insertUser: InsertUser) {
    const results = await sqlClient`
      INSERT INTO users (name, username, email, password, role)
      VALUES (${insertUser.name}, ${insertUser.username}, ${insertUser.email}, ${insertUser.password}, ${insertUser.role || 'user'})
      RETURNING *
    `;
    const u = results[0];
    return {
      id: u.id,
      name: u.name,
      username: u.username,
      email: u.email,
      password: u.password,
      role: u.role,
      profileImageUrl: u.profile_image_url,
      createdAt: u.created_at,
      updatedAt: u.updated_at
    };
  }

  async getArticles(params?: { category?: string, isFeatured?: string, trending?: string, search?: string }) {
    // Use raw sqlClient for this specific query to avoid Drizzle's internal non-template call
    const results = await sqlClient`SELECT * FROM articles`;
    
    let sortedArticles = [...results].sort((a, b) => {
      const dateA = a.created_at ? new Date(a.created_at).getTime() : 0;
      const dateB = b.created_at ? new Date(b.created_at).getTime() : 0;
      return dateB - dateA;
    });

    return sortedArticles.map(a => ({
      id: a.id,
      title: a.title,
      content: a.content,
      category: a.category,
      imageUrl: a.image_url,
      videoUrl: a.video_url,
      isFeatured: a.is_featured,
      viewCount: a.view_count,
      authorId: a.author_id,
      createdAt: a.created_at
    })).filter(a => {
      if (params?.category && a.category !== params.category) return false;
      if (params?.isFeatured === 'true' && !a.isFeatured) return false;
      if (params?.search && (a.title.toLowerCase().includes(params.search.toLowerCase()) || a.content.toLowerCase().includes(params.search.toLowerCase()))) return false;
      if (params?.category === 'Video' && !a.videoUrl) return false;
      return true;
    }).sort((a, b) => {
      if (params?.trending === 'true') {
        return (b.viewCount || 0) - (a.viewCount || 0);
      }
      return 0;
    });
  }

  async getArticle(id: number) {
    const results = await sqlClient`SELECT * FROM articles WHERE id = ${id}`;
    const a = results[0];
    if (!a) return undefined;
    return {
      id: a.id,
      title: a.title,
      content: a.content,
      category: a.category,
      imageUrl: a.image_url,
      videoUrl: a.video_url,
      isFeatured: a.is_featured,
      viewCount: a.view_count,
      authorId: a.author_id,
      createdAt: a.created_at
    };
  }

  async createArticle(insertArticle: InsertArticle) {
    const results = await sqlClient`
      INSERT INTO articles (title, content, category, image_url, video_url, is_featured, author_id)
      VALUES (${insertArticle.title}, ${insertArticle.content}, ${insertArticle.category}, ${insertArticle.imageUrl}, ${insertArticle.videoUrl}, ${insertArticle.isFeatured}, ${insertArticle.authorId})
      RETURNING *
    `;
    const a = results[0];
    return {
      id: a.id,
      title: a.title,
      content: a.content,
      category: a.category,
      imageUrl: a.image_url,
      videoUrl: a.video_url,
      isFeatured: a.is_featured,
      viewCount: a.view_count,
      authorId: a.author_id,
      createdAt: a.created_at
    };
  }

  async updateArticle(id: number, updateData: Partial<InsertArticle>) {
    const existing = await this.getArticle(id);
    if (!existing) throw new Error("Article not found");
    
    const finalData = { ...existing, ...updateData };
    const results = await sqlClient`
      UPDATE articles 
      SET title = ${finalData.title}, content = ${finalData.content}, category = ${finalData.category}, 
          image_url = ${finalData.imageUrl}, video_url = ${finalData.videoUrl}, is_featured = ${finalData.isFeatured}
      WHERE id = ${id}
      RETURNING *
    `;
    const a = results[0];
    return {
      id: a.id,
      title: a.title,
      content: a.content,
      category: a.category,
      imageUrl: a.image_url,
      videoUrl: a.video_url,
      isFeatured: a.is_featured,
      viewCount: a.view_count,
      authorId: a.author_id,
      createdAt: a.created_at
    };
  }

  async deleteArticle(id: number) {
    await sqlClient`DELETE FROM articles WHERE id = ${id}`;
  }

  async incrementArticleView(id: number) {
    await sqlClient`UPDATE articles SET view_count = view_count + 1 WHERE id = ${id}`;
  }

  async getComments(articleId: number) {
    const results = await sqlClient`
      SELECT c.*, u.name as user_name, u.profile_image_url as user_profile_image_url
      FROM comments c
      LEFT JOIN users u ON c.user_id = u.id::text
      WHERE c.article_id = ${articleId}
    `;

    return [...results].sort((a, b) => {
      const dateA = a.created_at ? new Date(a.created_at).getTime() : 0;
      const dateB = b.created_at ? new Date(b.created_at).getTime() : 0;
      return dateB - dateA;
    }).map(c => ({
      id: c.id,
      content: c.content,
      createdAt: c.created_at,
      user: {
        name: c.user_name,
        profileImageUrl: c.user_profile_image_url,
      }
    }));
  }

  async createComment(insertComment: InsertComment & { userId: string }) {
    const results = await sqlClient`
      INSERT INTO comments (article_id, user_id, content)
      VALUES (${insertComment.articleId}, ${insertComment.userId}, ${insertComment.content})
      RETURNING *
    `;
    return results[0];
  }

  async updateUser(id: number, updateData: any) {
    const existing = await sqlClient`SELECT * FROM users WHERE id = ${id}`;
    const u = existing[0];
    if (!u) throw new Error("User not found");

    const finalData = { ...u, ...updateData };
    const results = await sqlClient`
      UPDATE users
      SET name = ${finalData.name}, profile_image_url = ${finalData.profile_image_url}
      WHERE id = ${id}
      RETURNING *
    `;
    const res = results[0];
    return {
      id: res.id,
      name: res.name,
      username: res.username,
      email: res.email,
      password: res.password,
      role: res.role,
      profileImageUrl: res.profile_image_url,
      createdAt: res.created_at,
      updatedAt: res.updated_at
    };
  }

  async getReactions(articleId: number) {
    const results = await sqlClient`SELECT * FROM reactions WHERE article_id = ${articleId}`;
    return results;
  }

  async toggleReaction(insertReaction: InsertReaction & { userId: string }) {
    const existing = await sqlClient`
      SELECT * FROM reactions 
      WHERE article_id = ${insertReaction.articleId} AND user_id = ${insertReaction.userId} AND type = ${insertReaction.type}
    `;

    if (existing.length > 0) {
      await sqlClient`DELETE FROM reactions WHERE id = ${existing[0].id}`;
      return { removed: true as const };
    } else {
      const results = await sqlClient`
        INSERT INTO reactions (article_id, user_id, type)
        VALUES (${insertReaction.articleId}, ${insertReaction.userId}, ${insertReaction.type})
        RETURNING *
      `;
      return results[0];
    }
  }
}

export const storage = new DatabaseStorage();
