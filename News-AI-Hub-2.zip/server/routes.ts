import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import OpenAI from "openai";
import bcrypt from "bcrypt";
import { insertArticleSchema, insertUserSchema } from "@shared/schema";
import { db } from "./db";
import { sql } from "drizzle-orm";

// Auth middleware placeholder
const isAuthenticated = (req: any, res: any, next: any) => {
  if (req.session && req.session.userId) {
    return next();
  }
  return res.status(401).json({ message: "Unauthorized" });
};

// Initialize OpenAI client with Replit AI Integration URL & Key
const openai = new OpenAI({
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
});

export async function registerRoutes(app: Express): Promise<Server> {
  app.get("/api/auth/user", async (req, res) => {
    const session = req.session as any;
    if (session && session.userId) {
      // Special handling for static admin
      if (session.username === "admin" && session.userId === 1000000) {
        return res.json({
          id: 1000000,
          username: "admin",
          role: "admin",
          name: "Admin User",
          profileImageUrl: null
        });
      }

      const user = await storage.getUserByUsername(session.username);
      if (!user) return res.status(401).json({ message: "Not logged in" });
      return res.json({ 
        id: user.id, 
        username: user.username, 
        role: user.role,
        name: user.name,
        profileImageUrl: user.profileImageUrl 
      });
    }
    res.status(401).json({ message: "Not logged in" });
  });

  app.post("/api/user/profile", isAuthenticated, async (req: any, res) => {
    try {
      const { name, profileImageUrl } = req.body;
      const user = await storage.updateUser((req.session as any).userId, { name, profileImageUrl });
      res.json(user);
    } catch (err) {
      res.status(500).json({ message: "Internal error" });
    }
  });

  app.post("/api/register", async (req, res) => {
    try {
      const { name, username, email, password, confirmPassword } = req.body;

      if (!name || !username || !email || !password || !confirmPassword) {
        return res.status(400).json({ message: "All fields are required" });
      }

      if (password !== confirmPassword) {
        return res.status(400).json({ message: "Passwords do not match" });
      }

      const existingUser = await storage.getUserByEmail(email);
      if (existingUser) {
        return res.status(400).json({ message: "Email already registered" });
      }

      const hashedPassword = await bcrypt.hash(password, 10);
      const user = await storage.createUser({
        name,
        username,
        email,
        password: hashedPassword,
        role: "user"
      });

      // @ts-ignore
      (req.session as any).userId = user.id;
      // @ts-ignore
      (req.session as any).username = user.username;
      // @ts-ignore
      (req.session as any).role = user.role;

      res.status(201).json({ 
        message: "User registered successfully",
        user: { id: user.id, name: user.name, username: user.username, email: user.email, role: user.role }
      });
    } catch (err) {
      console.error("Registration error:", err);
      res.status(500).json({ message: "Internal error during registration" });
    }
  });

  app.post("/api/login", async (req, res) => {
    try {
      const { username, password } = req.body;

      if (!username || !password) {
        return res.status(400).json({ message: "Username/Email and password are required" });
      }

      let user;
      if (username.includes("@")) {
        user = await storage.getUserByEmail(username);
      } else {
        user = await storage.getUserByUsername(username);
      }

      if (!user) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      const isPasswordCorrect = await bcrypt.compare(password, user.password);
      if (!isPasswordCorrect) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      // @ts-ignore
      (req.session as any).userId = user.id;
      // @ts-ignore
      (req.session as any).username = user.username;
      // @ts-ignore
      (req.session as any).role = user.role;

      res.json({ message: "Login successful", user: { id: user.id, username: user.username, role: user.role } });
    } catch (err) {
      console.error("Login error:", err);
      res.status(500).json({ message: "Internal error during login" });
    }
  });

  app.get("/api/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: "Could not log out" });
      }
      res.clearCookie('connect.sid'); // Clear the session cookie
      res.redirect("/"); // Redirect to home page after logout
    });
  });

  app.post("/api/admin/articles", isAuthenticated, async (req: any, res) => {
    try {
      if (req.session.role !== "admin") {
        return res.status(403).json({ message: "Forbidden: Admin access only" });
      }
      const input = insertArticleSchema.parse(req.body);
      const article = await storage.createArticle({ ...input, authorId: String((req.session as any).userId) });
      res.status(201).json(article);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      res.status(500).json({ message: "Internal error" });
    }
  });

  app.post("/api/admin-login", async (req, res) => {
    try {
      const { username, password } = req.body;
      if (username === "admin" && password === "joshua") {
        const session = req.session as any;
        session.userId = 1000000; // Use a high number for static admin ID
        session.username = "admin";
        session.role = "admin";
        
        // Ensure session is saved before responding
        req.session.save((err) => {
          if (err) {
            console.error("Session save error:", err);
            return res.status(500).json({ message: "Failed to save session" });
          }
          res.json({ 
            message: "Admin login successful", 
            user: { id: 1000000, username: "admin", role: "admin" }
          });
        });
        return;
      }
      res.status(401).json({ message: "Unauthorized: Invalid admin credentials" });
    } catch (err) {
      console.error("Admin login error:", err);
      res.status(500).json({ message: "Internal error" });
    }
  });

  // Articles
  app.get(api.articles.list.path, async (req, res) => {
    try {
      const articles = await storage.getArticles(req.query);
      res.json(articles);
    } catch (err) {
      res.status(500).json({ message: "Internal error" });
    }
  });

  app.get(api.articles.get.path, async (req, res) => {
    try {
      const article = await storage.getArticle(Number(req.params.id));
      if (!article) return res.status(404).json({ message: 'Not found' });
      res.json(article);
    } catch (err) {
      res.status(500).json({ message: "Internal error" });
    }
  });

  app.post(api.articles.create.path, isAuthenticated, async (req: any, res) => {
    try {
      if (req.session.role !== "admin") {
        return res.status(403).json({ message: "Forbidden: Admin access only" });
      }
      const input = api.articles.create.input.parse(req.body);
      const article = await storage.createArticle({ ...input, authorId: String((req.session as any).userId) });
      res.status(201).json(article);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      res.status(500).json({ message: "Internal error" });
    }
  });

  app.put(api.articles.update.path, isAuthenticated, async (req, res) => {
    try {
      const input = api.articles.update.input.parse(req.body);
      const article = await storage.updateArticle(Number(req.params.id), input);
      res.json(article);
    } catch (err) {
      res.status(400).json({ message: "Invalid request" });
    }
  });

  app.delete(api.articles.delete.path, isAuthenticated, async (req, res) => {
    try {
      await storage.deleteArticle(Number(req.params.id));
      res.status(204).send();
    } catch (err) {
      res.status(500).json({ message: "Internal error" });
    }
  });

  app.post(api.articles.incrementView.path, async (req, res) => {
    try {
      await storage.incrementArticleView(Number(req.params.id));
      res.json({ success: true });
    } catch (err) {
      res.status(500).json({ message: "Internal error" });
    }
  });

  // Comments
  app.get(api.comments.list.path, async (req, res) => {
    try {
      const comments = await storage.getComments(Number(req.params.articleId));
      res.json(comments);
    } catch (err) {
      res.status(500).json({ message: "Internal error" });
    }
  });

  app.post(api.comments.create.path, isAuthenticated, async (req: any, res) => {
    try {
      const input = api.comments.create.input.parse(req.body);
      const article = await storage.createComment({
        content: input.content,
        articleId: Number(req.params.articleId),
        userId: String((req.session as any).userId)
      });
      res.status(201).json(article);
    } catch (err) {
      res.status(400).json({ message: "Invalid request" });
    }
  });

  // Reactions
  app.get(api.reactions.list.path, async (req, res) => {
    try {
      const reactions = await storage.getReactions(Number(req.params.articleId));
      res.json(reactions);
    } catch (err) {
      res.status(500).json({ message: "Internal error" });
    }
  });

  app.post(api.reactions.toggle.path, isAuthenticated, async (req: any, res) => {
    try {
      const input = api.reactions.toggle.input.parse(req.body);
      const result = await storage.toggleReaction({
        type: input.type,
        articleId: Number(req.params.articleId),
        userId: String((req.session as any).userId)
      });
      res.json(result);
    } catch (err) {
      res.status(400).json({ message: "Invalid request" });
    }
  });

  // AI Chat
  app.post(api.ai.chat.path, async (req, res) => {
    try {
      const { message, personality, articleContextId } = req.body;
      let systemPrompt = "You are a helpful AI assistant for a news platform.";
      
      if (personality) {
        systemPrompt += ` Your personality is: ${personality}.`;
      }
      
      let contextMsg = "";
      if (articleContextId) {
        const article = await storage.getArticle(Number(articleContextId));
        if (article) {
          contextMsg = `Context - The user is currently reading this news article titled "${article.title}". Content: ${article.content.substring(0, 1000)}...`;
        }
      }

      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          { role: "system", content: systemPrompt },
          ...(contextMsg ? [{ role: "system" as const, content: contextMsg }] : []),
          { role: "user", content: message }
        ]
      });

      res.json({ reply: response.choices[0]?.message?.content || "I'm sorry, I couldn't generate a response." });
    } catch (err) {
      console.error(err);
      res.status(500).json({ message: "Failed to generate AI response" });
    }
  });

  // Basic seed function
  async function seed() {
    try {
      // First, check if the articles table exists
      try {
        await sqlClient`SELECT count(*) FROM articles`;
      } catch (e: any) {
        if (e.message && (e.message.includes('relation "articles" does not exist') || e.message.includes('42P01'))) {
          console.log("Articles table does not exist, skipping seed");
          return;
        }
      }

      const articlesList = await storage.getArticles();
      if (articlesList.length === 0) {
        await storage.createArticle({
          title: "Tech Giant Unveils Revolutionary AI Model",
          content: "In a surprising event today, a major tech company revealed their newest AI model that promises to change the landscape of computing forever. The model is capable of understanding deep contexts and performing complex reasoning tasks...",
          category: "Technology",
          authorId: "seed-author",
          isFeatured: true,
          imageUrl: "https://images.unsplash.com/photo-1677442136019-21780ecad995"
        });
        await storage.createArticle({
          title: "Local Sports Team Wins Championship",
          content: "The city erupted in celebration last night as the local team secured their first championship in over two decades. The final score was...",
          category: "Sports",
          authorId: "seed-author",
          isFeatured: false,
          imageUrl: "https://images.unsplash.com/photo-1461896836934-ffe607ba8211"
        });
        await storage.createArticle({
          title: "New Policy Impacts Entertainment Industry",
          content: "Lawmakers have introduced a new policy that will strictly regulate how digital content is distributed...",
          category: "Entertainment",
          authorId: "seed-author",
          isFeatured: false,
          imageUrl: "https://images.unsplash.com/photo-1603190287605-e6ade32fa852"
        });
      }
    } catch (e) {
      console.error("Failed to seed", e);
    }
  }

  // Ensure tables are created before seeding
  // In a real app, you'd use migrations, but for this template we'll just try to seed
  // and handle the missing table error gracefully.
  setTimeout(seed, 5000);

  const httpServer = createServer(app);
  return httpServer;
}
